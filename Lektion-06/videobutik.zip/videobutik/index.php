<?php
/**********************************************
 *       index.php
 *       Applikationens startsida
 *       Importera nödvändiga scripts
 **********************************************/

// Hämta sidhuvud
require_once 'header.php';

// Visa alla filmer
require_once 'show-movies.php';

// Hämta sidfot
require_once 'footer.php';