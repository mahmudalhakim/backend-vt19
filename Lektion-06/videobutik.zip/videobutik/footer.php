<?php
/**********************************************
 *       footer.php
 *       Sidfot, inkluderas längst ner på alla 
 *       sidor som har en view (HTML-kod)
 **********************************************/
?> 
<hr>
<footer>
  Copyright &copy; <?php echo date('Y'); ?>
</footer>
</body>
</html>